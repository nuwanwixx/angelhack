
<div class="text-center" style="font-family: Arial; color: white; margin-top: 200px; margin-bottom: 20px;">
<hr>

	Copyright &copy by Work 'n' Hire
</div>